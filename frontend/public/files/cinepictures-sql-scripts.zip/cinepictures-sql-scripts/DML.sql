-- Group 52: Julio Jimenez and Jesus Rodriguez
-- Step 3 - 5/8/2025

-- : will be used to denote variables passed to the SQL statements
--  ex. :firstNameInput, :lastNameInput, :emailInput, :phoneNumberInput

-- Customers Table-------------------------------------------------------

-- Get all customers
SELECT customerID, firstName, lastName, email, phoneNumber 
FROM Customers;

-- Add a new customer
INSERT INTO Customers (firstName, lastName, email, phoneNumber) 
VALUES (:firstNameInput, :lastNameInput, :emailInput, :phoneNumberInput);

-- Update an existing customer
UPDATE Customers
SET firstName = :firstNameInput,
    lastName = :lastNameInput,
    email = :emailInput,
    phoneNumber = :phoneNumberInput
WHERE customerID = :customerID_to_update;

-- Delete a customer
DELETE FROM Customers
WHERE customerID = :customerID_to_delete;

-- Get a customer details by ID
SELECT customerID, firstName, lastName, email, phoneNumber 
FROM Customers
WHERE customerID = :customerID_selected;

-- Movies Table-------------------------------------------------------

-- Get all movies
SELECT movieID, title, director, releaseYear, genre, runtime, rating 
FROM Movies;

-- Add a new movie
INSERT INTO Movies (title, director, releaseYear, genre, runtime, rating) 
VALUES (:titleInput, :directorInput, :releaseYearInput, :genreInput, :runtimeInput, :ratingInput);

-- Update an existing movie
UPDATE Movies
SET title = :titleInput,
    director = :directorInput,
    releaseYear = :releaseYearInput,
    genre = :genreInput,
    runtime = :runtimeInput,
    rating = :ratingInput
WHERE movieID = :movieID_to_update;

-- Delete a movie
DELETE FROM Movies
WHERE movieID = :movieID_to_delete;

-- Get a movie by ID
SELECT movieID, title, director, releaseYear, genre, runtime, rating 
FROM Movies
WHERE movieID = :movieID_selected;

-- EmployeeRoles Table-------------------------------------------------------

-- Get all employee roles
SELECT roleID, roleName 
FROM EmployeeRoles
ORDER BY roleID ASC;

-- Add a new employee role
INSERT INTO EmployeeRoles (roleName) 
VALUES (:roleNameInput);

-- Update an existing employee role
UPDATE EmployeeRoles
SET roleName = :roleNameInput
WHERE roleID = :roleID_to_update;

-- Delete an employee role
DELETE FROM EmployeeRoles
WHERE roleID = :roleID_to_delete;

-- Get an employee role by ID
SELECT roleID, roleName 
FROM EmployeeRoles
WHERE roleID = :roleID_selected;

-- Employees Table-------------------------------------------------------

-- Get all employees (with formatted role)
SELECT 
  e.employeeID,
  e.firstName,
  e.lastName,
  e.email,
  CONCAT(e.roleID, ' - ', r.roleName) AS employeeRoleID
FROM Employees e
JOIN EmployeeRoles r ON e.roleID = r.roleID
ORDER BY e.lastName;

-- Add a new employee
INSERT INTO Employees (firstName, lastName, email, phoneNumber, roleID) 
VALUES (:firstNameInput, :lastNameInput, :emailInput, :phoneNumberInput, :roleIDInput);

-- Update an existing employee
UPDATE Employees
SET firstName = :firstNameInput,
    lastName = :lastNameInput,
    email = :emailInput,
    phoneNumber = :phoneNumberInput,
    roleID = :roleIDInput
WHERE employeeID = :employeeID_to_update;

-- Delete an employee
DELETE FROM Employees
WHERE employeeID = :employeeID_to_delete;

-- Get an employee by ID (formatted role included)
SELECT 
  e.employeeID,
  e.firstName,
  e.lastName,
  e.email,
  CONCAT(e.roleID, ' - ', r.roleName) AS employeeRoleID
FROM Employees e
JOIN EmployeeRoles r ON e.roleID = r.roleID
WHERE e.employeeID = :employeeID_selected;

-- Screenings Table-------------------------------------------------------

-- Get all screenings (with formatted movie and employee FKs)
SELECT 
  s.screeningID,
  s.startTime,
  s.endTime,
  s.screenNumber,
  s.totalCapacity,
  CONCAT(s.employeeID, ' - ', e.firstName, ' ', e.lastName) AS employeeID,
  CONCAT(s.movieID, ' - ', m.title) AS movieID
FROM Screenings s
JOIN Movies m ON s.movieID = m.movieID
JOIN Employees e ON s.employeeID = e.employeeID
ORDER BY s.startTime;

-- Add a new screening
INSERT INTO Screenings (movieID, screenNumber, startTime, endTime, totalCapacity, employeeID) 
VALUES (:movieIDInput, :screenNumberInput, :startTimeInput, :endTimeInput, :totalCapacityInput, :employeeIDInput);

-- Update an existing screening
UPDATE Screenings
SET movieID = :movieIDInput,
    screenNumber = :screenNumberInput,
    startTime = :startTimeInput,
    endTime = :endTimeInput,
    totalCapacity = :totalCapacityInput,
    employeeID = :employeeIDInput
WHERE screeningID = :screeningID_to_update;

-- Delete a screening
DELETE FROM Screenings
WHERE screeningID = :screeningID_to_delete;

-- Get a screening by ID (with formatted movie and employee FKs)
SELECT 
  s.screeningID,
  s.startTime,
  s.endTime,
  s.screenNumber,
  s.totalCapacity,
  CONCAT(s.employeeID, ' - ', e.firstName, ' ', e.lastName) AS employeeID,
  CONCAT(s.movieID, ' - ', m.title) AS movieID
FROM Screenings s
JOIN Movies m ON s.movieID = m.movieID
JOIN Employees e ON s.employeeID = e.employeeID
WHERE s.screeningID = :screeningID_selected;

-- Tickets Table-------------------------------------------------------
-- Get all tickets (with formatted screening and customer FKs)
SELECT 
  t.ticketID,
  t.price,
  t.purchaseDate,
  CONCAT(t.customerID, ' - ', c.firstName, ' ', c.lastName) AS customerID,
  CONCAT(t.screeningID, ' - ', m.title, ' @ ', DATE_FORMAT(s.startTime, '%Y-%m-%d %H:%i')) AS screeningID
FROM Tickets t
JOIN Customers c ON t.customerID = c.customerID
JOIN Screenings s ON t.screeningID = s.screeningID
JOIN Movies m ON s.movieID = m.movieID
ORDER BY t.ticketID;

-- Add a new ticket
INSERT INTO Tickets (screeningID, customerID, purchaseDate, price) 
VALUES (:screeningIDInput, :customerIDInput, :purchaseDateInput, :priceInput);

-- Update an existing ticket
UPDATE Tickets
SET screeningID = :screeningIDInput,
    customerID = :customerIDInput,
    purchaseDate = :purchaseDateInput,
    price = :priceInput
WHERE ticketID = :ticketID_to_update;

-- Delete a ticket
DELETE FROM Tickets
WHERE ticketID = :ticketID_to_delete;

-- Get a ticket by ID (with formatted screening and customer FKs)
SELECT 
  t.ticketID,
  t.price,
  t.purchaseDate,
  CONCAT(t.customerID, ' - ', c.firstName, ' ', c.lastName) AS customerID,
  CONCAT(t.screeningID, ' - ', m.title, ' @ ', DATE_FORMAT(s.startTime, '%Y-%m-%d %H:%i')) AS screeningID
FROM Tickets t
JOIN Customers c ON t.customerID = c.customerID
JOIN Screenings s ON t.screeningID = s.screeningID
JOIN Movies m ON s.movieID = m.movieID
WHERE t.ticketID = :ticketID_selected;