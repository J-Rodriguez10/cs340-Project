-- Group 52: Jesus Rodriguez and Julio Jimenez

-- Use the appropriate database
USE cs340_rodrij23;


-- Citation for the following code:
-- Date: 2025-05-19
-- Based on assignment specs and AI-assisted structure.
-- Prompt: Can you help me create a full MySQL stored procedure named sp_ResetDatabase() 
-- that drops all tables, recreates them using my DDL schema, and reinserts my sample data
-- all based on my cleaned DDL.sql and DML.sql files?

-- =======================================
-- RESET DATABASE PROCEDURE
-- =======================================

DROP PROCEDURE IF EXISTS sp_ResetDatabase;

DELIMITER //
CREATE PROCEDURE sp_ResetDatabase()
BEGIN
  -- UTC Timezone
  SET time_zone = '+00:00';
  
  -- Drop tables in reverse dependency order
  DROP TABLE IF EXISTS Tickets;
  DROP TABLE IF EXISTS Screenings;
  DROP TABLE IF EXISTS Employees;
  DROP TABLE IF EXISTS EmployeeRoles;
  DROP TABLE IF EXISTS Customers;
  DROP TABLE IF EXISTS Movies;

  -- Create Movies table
  CREATE TABLE Movies (
    movieID INT NOT NULL AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    director VARCHAR(100),
    releaseYear INT,
    genre VARCHAR(100),
    runtime INT,
    rating VARCHAR(10),
    PRIMARY KEY (movieID)
  );

  -- Create Customers table
  CREATE TABLE Customers (
    customerID INT NOT NULL AUTO_INCREMENT,
    firstName VARCHAR(100) NOT NULL,
    lastName VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phoneNumber VARCHAR(20),
    PRIMARY KEY (customerID),
    UNIQUE (email)
  );

  -- Create EmployeeRoles table
  CREATE TABLE EmployeeRoles (
    roleID INT NOT NULL AUTO_INCREMENT,
    roleName VARCHAR(50) NOT NULL,
    PRIMARY KEY (roleID),
    UNIQUE (roleName)
  );

  -- Create Employees table
  CREATE TABLE Employees (
    employeeID INT NOT NULL AUTO_INCREMENT,
    firstName VARCHAR(100) NOT NULL,
    lastName VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    phoneNumber VARCHAR(20),
    roleID INT NOT NULL,
    PRIMARY KEY (employeeID),
    UNIQUE (email),
    FOREIGN KEY (roleID)
      REFERENCES EmployeeRoles(roleID)
      ON DELETE CASCADE
      ON UPDATE NO ACTION
  );

  -- Create Screenings table (with ON DELETE CASCADE for employeeID and movieID)
  CREATE TABLE Screenings (
    screeningID INT NOT NULL AUTO_INCREMENT,
    movieID INT NOT NULL,
    screenNumber INT NOT NULL,
    startTime TIMESTAMP(2) NOT NULL,
    endTime TIMESTAMP(2),
    totalCapacity INT NOT NULL,
    employeeID INT NOT NULL,
    PRIMARY KEY (screeningID),
    FOREIGN KEY (movieID)
      REFERENCES Movies(movieID)
      ON DELETE CASCADE
      ON UPDATE NO ACTION,
    FOREIGN KEY (employeeID)
      REFERENCES Employees(employeeID)
      ON DELETE CASCADE
      ON UPDATE NO ACTION
  );

  -- Create Tickets table
  CREATE TABLE Tickets (
    ticketID INT NOT NULL AUTO_INCREMENT,
    screeningID INT NOT NULL,
    customerID INT NOT NULL,
    purchaseDate TIMESTAMP(2) NOT NULL,
    price DECIMAL(5,2) NOT NULL,
    PRIMARY KEY (ticketID),
    FOREIGN KEY (customerID)
      REFERENCES Customers(customerID)
      ON DELETE CASCADE
      ON UPDATE NO ACTION,
    FOREIGN KEY (screeningID)
      REFERENCES Screenings(screeningID)
      ON DELETE CASCADE
      ON UPDATE NO ACTION
  );

  -- Insert sample data

  -- Movies
  INSERT INTO Movies (movieID, title, director, releaseYear, genre, runtime, rating) VALUES
    (1, 'The Avengers: Doomsday', 'A. Director', 2025, 'Action', 120, 'PG-13'),
    (2, 'Dune Messiah', 'D. Villeneuve', 2025, 'Mystery', 110, 'PG-13'),
    (3, 'Sinners', 'R. Coogler', 2025, 'Thriller', 135, 'R'),
    (4, 'The Odyssey', 'C. Nolan', 2025, 'Drama', 195, 'PG-13'),
    (5, 'The Batman', 'M. Reeves', 2022, 'Thriller', 205, 'PG-13');

  -- Employee Roles
  INSERT INTO EmployeeRoles (roleID, roleName) VALUES
    (1, 'Manager'),
    (2, 'Usher'),
    (3, 'Ticket Agent'),
    (4, 'Projectionist');

  -- Employees
  INSERT INTO Employees (employeeID, firstName, lastName, email, phoneNumber, roleID) VALUES
    (201, 'Eveyln', 'Garcia', 'eveyln.garcia@cinepic.com', '555-0101-0001', 1),
    (202, 'Isabella', 'Johnson', 'isabella.johnson@cinepic.com', '555-0102-0002', 2),
    (203, 'Charlie', 'Goldberg', 'charlie.goldberg@cinepic.com', '555-0103-0003', 3),
    (204, 'Danny', 'Prince', 'danny.p@cinepic.com', '555-0104-0004', 2),
    (205, 'Mateo', 'Huminsky', 'mateo.huminsky@cinepic.com', '555-0105-0004', 4);

  -- Customers
  INSERT INTO Customers (customerID, firstName, lastName, email, phoneNumber) VALUES
    (1, 'David', 'Johnson', 'david.johnson@gmail.com', '555-5001-0001'),
    (2, 'Gabriella', 'Hernandez', 'gabriella.h@gmail.com', '555-5002-0002'),
    (3, 'Peter', 'Parker', 'peter.parker@gmail.com', '555-5003-0003'),
    (4, 'Juan', 'Santos', 'juan.santos@gmail.com', '555-5004-0004'),
    (5, 'Adam', 'Sandler', 'adam.s@gmail.com', '555-5005-0005');

  -- Screenings
  INSERT INTO Screenings (screeningID, movieID, screenNumber, startTime, endTime, totalCapacity, employeeID) VALUES
    (11001, 1, 1, '2025-04-29 14:00:00', '2025-04-29 16:00:00', 150, 202),
    (11002, 5, 5, '2025-04-29 17:00:00', '2025-04-29 20:25:00', 50, 205),
    (11003, 2, 2, '2025-04-29 15:30:00', '2025-04-29 17:20:00', 75, 202),
    (11004, 3, 3, '2025-04-29 19:00:00', '2025-04-29 21:15:00', 75, 204),
    (11005, 4, 2, '2025-04-29 18:00:00', '2025-04-29 21:15:00', 75, 205);

  -- Tickets
  INSERT INTO Tickets (ticketID, screeningID, customerID, purchaseDate, price) VALUES
    (1, 11001, 4, '2025-04-28 10:00:00', 15.00),
    (2, 11001, 4, '2025-04-28 10:00:00', 15.00),
    (3, 11003, 1, '2025-04-28 11:30:00', 12.50),
    (4, 11004, 2, '2025-04-28 14:00:00', 12.50),
    (5, 11001, 3, '2025-04-28 16:00:00', 15.00),
    (6, 11005, 3, '2025-04-28 17:00:00', 12.50),
    (7, 11002, 5, '2025-04-28 15:00:00', 10.00);
    
END //
DELIMITER ;

