-- Group 52: Jesus Rodriguez and Julio Jimenez

-- =======================================
-- CUSTOMERS:
-- =======================================
-- Citation for the following code:
-- Date: 2025-05-29
-- Based on Customers DDL section and AI-assisted structure.
-- Prompt: Can you help me create stored procedures named sp_AddCustomer, sp_UpdateCustomerByID, 
-- and sp_DeleteCustomerByID for managing entries in the Customers table?

-- CREATE: Procedure to add a customer:
DROP PROCEDURE IF EXISTS sp_AddCustomer;
DELIMITER //
CREATE PROCEDURE sp_AddCustomer(
  IN firstNameInput VARCHAR(100),
  IN lastNameInput VARCHAR(100),
  IN emailInput VARCHAR(255),
  IN phoneNumberInput VARCHAR(20)
)
BEGIN
  INSERT INTO Customers (firstName, lastName, email, phoneNumber)
  VALUES (firstNameInput, lastNameInput, emailInput, phoneNumberInput);
END //
DELIMITER ;


-- UPDATE: Procedure to update customer:
DROP PROCEDURE IF EXISTS sp_UpdateCustomerByID;
DELIMITER //
CREATE PROCEDURE sp_UpdateCustomerByID(
  IN customerIDInput INT,
  IN firstNameInput VARCHAR(100),
  IN lastNameInput VARCHAR(100),
  IN emailInput VARCHAR(255),
  IN phoneNumberInput VARCHAR(20)
)
BEGIN
  UPDATE Customers
  SET 
    firstName = firstNameInput,
    lastName = lastNameInput,
    email = emailInput,
    phoneNumber = phoneNumberInput
  WHERE customerID = customerIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;


-- DELETE: Procedure to delete customer: 
DROP PROCEDURE IF EXISTS sp_DeleteCustomerByID;
DELIMITER //
CREATE PROCEDURE sp_DeleteCustomerByID(
  IN customerIDInput INT
)
BEGIN
  DELETE FROM Customers
  WHERE customerID = customerIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;

-- =======================================
-- SCREENINGS:
-- =======================================
-- Citation for the following code:
-- Date: 2025-05-29
-- Based on Screenings DDL section and AI-assisted structure.
-- Prompt:1) Can you help me create stored procedures named sp_AddScreening, sp_UpdateScreeningByID, 
-- and sp_DeleteScreeningByID for managing entries in the Screenings table?
-- 2) Create a trigger where when the user changes the endtime for a movie, the corresponding scrrening's
-- endtime will be updated aswell.

-- CREATE: Procedure to add a screening
DROP PROCEDURE IF EXISTS sp_AddScreening;
DELIMITER //
CREATE PROCEDURE sp_AddScreening(
  IN movieIDInput INT,
  IN screenNumberInput INT,
  IN startTimeInput TIMESTAMP,
  IN endTimeInput TIMESTAMP,
  IN totalCapacityInput INT,
  IN employeeIDInput INT
)
BEGIN
  INSERT INTO Screenings (movieID, screenNumber, startTime, endTime, totalCapacity, employeeID)
  VALUES (movieIDInput, screenNumberInput, startTimeInput, endTimeInput, totalCapacityInput, employeeIDInput);
END //
DELIMITER ;

-- UPDATE: Procedure to update a screening 
DROP PROCEDURE IF EXISTS sp_UpdateScreeningByID;
DELIMITER //
CREATE PROCEDURE sp_UpdateScreeningByID(
  IN screeningIDInput INT,
  IN movieIDInput INT,
  IN screenNumberInput INT,
  IN startTimeInput TIMESTAMP,
  IN endTimeInput TIMESTAMP,
  IN totalCapacityInput INT,
  IN employeeIDInput INT
)
BEGIN
  UPDATE Screenings
  SET 
    movieID = movieIDInput,
    screenNumber = screenNumberInput,
    startTime = startTimeInput,
    endTime = endTimeInput,
    totalCapacity = totalCapacityInput,
    employeeID = employeeIDInput
  WHERE screeningID = screeningIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;

-- DELETE: Procedure to delete a screening
DROP PROCEDURE IF EXISTS sp_DeleteScreeningByID;
DELIMITER //
CREATE PROCEDURE sp_DeleteScreeningByID(
  IN screeningIDInput INT
)
BEGIN
  DELETE FROM Screenings
  WHERE screeningID = screeningIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;

-- =======================================
-- TICEKTS:
-- =======================================
-- Citation for the following code:
-- Date: 2025-05-29
-- Based on Tickets DDL section and AI-assisted structure.
-- Prompt: Can you help me create stored procedures named sp_AddTicket, sp_UpdateTicketByID, 
-- and sp_DeleteTicketByID for managing entries in the Tickets table?

-- CREATE: Procedure to add a ticket
DROP PROCEDURE IF EXISTS sp_AddTicket;
DELIMITER //
CREATE PROCEDURE sp_AddTicket(
  IN screeningIDInput INT,
  IN customerIDInput INT,
  IN purchaseDateInput TIMESTAMP,
  IN priceInput DECIMAL(5,2)
)
BEGIN
  INSERT INTO Tickets (screeningID, customerID, purchaseDate, price)
  VALUES (screeningIDInput, customerIDInput, purchaseDateInput, priceInput);
END //
DELIMITER ;

-- UPDATE: Procedure to update a ticket
DROP PROCEDURE IF EXISTS sp_UpdateTicketByID;
DELIMITER //
CREATE PROCEDURE sp_UpdateTicketByID(
  IN ticketIDInput INT,
  IN screeningIDInput INT,
  IN customerIDInput INT,
  IN purchaseDateInput TIMESTAMP,
  IN priceInput DECIMAL(5,2)
)
BEGIN
  UPDATE Tickets
  SET 
    screeningID = screeningIDInput,
    customerID = customerIDInput,
    purchaseDate = purchaseDateInput,
    price = priceInput
  WHERE ticketID = ticketIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;

-- DELETE: Procedure to delete a ticket
DROP PROCEDURE IF EXISTS sp_DeleteTicketByID;
DELIMITER //
CREATE PROCEDURE sp_DeleteTicketByID(
  IN ticketIDInput INT
)
BEGIN
  DELETE FROM Tickets
  WHERE ticketID = ticketIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;

-- =======================================
-- EMPLOYEES:
-- =======================================
-- Citation for the following code:
-- Date: 2025-05-29
-- Based on Employees DDL section and AI-assisted structure.
-- Prompt: Can you help me create stored procedures named sp_AddEmployee, sp_UpdateEmployeeByID, 
-- and sp_DeleteEmployeeByID for managing entries in the Employees table?

-- CREATE: Procedure to add an employee
DROP PROCEDURE IF EXISTS sp_AddEmployee;
DELIMITER //
CREATE PROCEDURE sp_AddEmployee(
  IN firstNameInput VARCHAR(100),
  IN lastNameInput VARCHAR(100),
  IN emailInput VARCHAR(255),
  IN phoneNumberInput VARCHAR(20),
  IN roleIDInput INT
)
BEGIN
  INSERT INTO Employees (firstName, lastName, email, phoneNumber, roleID)
  VALUES (firstNameInput, lastNameInput, emailInput, phoneNumberInput, roleIDInput);
END //
DELIMITER ;

-- UPDATE: Procedure to update an employee
DROP PROCEDURE IF EXISTS sp_UpdateEmployeeByID;
DELIMITER //
CREATE PROCEDURE sp_UpdateEmployeeByID(
  IN employeeIDInput INT,
  IN firstNameInput VARCHAR(100),
  IN lastNameInput VARCHAR(100),
  IN emailInput VARCHAR(255),
  IN phoneNumberInput VARCHAR(20),
  IN roleIDInput INT
)
BEGIN
  UPDATE Employees
  SET 
    firstName = firstNameInput,
    lastName = lastNameInput,
    email = emailInput,
    phoneNumber = phoneNumberInput,
    roleID = roleIDInput
  WHERE employeeID = employeeIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;

-- DELETE: Procedure to delete an employee
DROP PROCEDURE IF EXISTS sp_DeleteEmployeeByID;
DELIMITER //
CREATE PROCEDURE sp_DeleteEmployeeByID(
  IN employeeIDInput INT
)
BEGIN
  DELETE FROM Employees
  WHERE employeeID = employeeIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;


-- =======================================
-- EMPLOYEE ROLES:
-- =======================================
-- Citation for the following code:
-- Date: 2025-05-29
-- Based on EmployeeRoles DDL section and AI-assisted structure.
-- Prompt: Can you help me create stored procedures named sp_AddEmployeeRole, sp_UpdateEmployeeRoleByID, 
-- and sp_DeleteEmployeeRoleByID for managing entries in the EmployeeRoles table?

-- CREATE: Procedure to create an employee role
DROP PROCEDURE IF EXISTS sp_AddEmployeeRole;
DELIMITER //
CREATE PROCEDURE sp_AddEmployeeRole(
  IN roleNameInput VARCHAR(50)
)
BEGIN
  INSERT INTO EmployeeRoles (roleName)
  VALUES (roleNameInput);
END //
DELIMITER ;

-- UPDATE: Procedure to update an employee role
DROP PROCEDURE IF EXISTS sp_UpdateEmployeeRoleByID;
DELIMITER //
CREATE PROCEDURE sp_UpdateEmployeeRoleByID(
  IN roleIDInput INT,
  IN roleNameInput VARCHAR(50)
)
BEGIN
  UPDATE EmployeeRoles
  SET roleName = roleNameInput
  WHERE roleID = roleIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;

-- DELETE: Procedure to delete an employee role
DROP PROCEDURE IF EXISTS sp_DeleteEmployeeRoleByID;
DELIMITER //
CREATE PROCEDURE sp_DeleteEmployeeRoleByID(
  IN roleIDInput INT
)
BEGIN
  DELETE FROM EmployeeRoles
  WHERE roleID = roleIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;

-- =======================================
-- MOVIES
-- =======================================
-- Citation for the following code:
-- Date: 2025-05-29
-- Based on assignment specs and AI-assisted structure.
-- Prompt: Can you help me create stored procedures for adding, updating, and deleting movies in the Movies table?

-- Procedure to add a movie:
DROP PROCEDURE IF EXISTS sp_AddMovie;
DELIMITER //
CREATE PROCEDURE sp_AddMovie(
  IN titleInput VARCHAR(255),
  IN directorInput VARCHAR(100),
  IN releaseYearInput INT,
  IN genreInput VARCHAR(100),
  IN runtimeInput INT,
  IN ratingInput VARCHAR(10)
)
BEGIN
  INSERT INTO Movies (title, director, releaseYear, genre, runtime, rating)
  VALUES (titleInput, directorInput, releaseYearInput, genreInput, runtimeInput, ratingInput);
END //
DELIMITER ;

-- Procedure to update a movie by ID:
DROP PROCEDURE IF EXISTS sp_UpdateMovieByID;
DELIMITER //
CREATE PROCEDURE sp_UpdateMovieByID(
  IN movieIDInput INT,
  IN titleInput VARCHAR(255),
  IN directorInput VARCHAR(100),
  IN releaseYearInput INT,
  IN genreInput VARCHAR(100),
  IN runtimeInput INT,
  IN ratingInput VARCHAR(10)
)
BEGIN
  UPDATE Movies
  SET 
    title = titleInput,
    director = directorInput,
    releaseYear = releaseYearInput,
    genre = genreInput,
    runtime = runtimeInput,
    rating = ratingInput
  WHERE movieID = movieIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;

-- Procedure to delete a movie by ID:
DROP PROCEDURE IF EXISTS sp_DeleteMovieByID;
DELIMITER //
CREATE PROCEDURE sp_DeleteMovieByID(
  IN movieIDInput INT
)
BEGIN
  DELETE FROM Movies
  WHERE movieID = movieIDInput;

  SELECT ROW_COUNT() AS affectedRows;
END //
DELIMITER ;



